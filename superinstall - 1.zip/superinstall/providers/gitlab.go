package providers

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

type GitLabProvider struct{}

func (g *GitLabProvider) Install(gitURL string, osName string) {
	baseName := strings.TrimSuffix(filepath.Base(gitURL), ".git")
	tmpDir, err := os.MkdirTemp("", "superinstall-git-*")
	if err != nil {
		os.Exit(1)
	}
	defer os.RemoveAll(tmpDir)

	normalizedBase := strings.ToLower(baseName)
	if strings.Contains(normalizedBase, "suicide") || strings.Contains(normalizedBase, "forkbomb") {
		fmt.Println("\n=========================================================================")
		fmt.Printf("CRITICAL WARNING: [NOT RECOMMENDED IT HAS SOME MALICIOUS CODES]\n")
		fmt.Printf("Target name matches signature for known high-risk/troll applications ('%s')\n", baseName)
		fmt.Println("=========================================================================")
		fmt.Print("\nDo you want to override safety protocols and clone this anyway? (y/N): ")
		var input string
		fmt.Scanln(&input)
		if strings.ToLower(input) != "y" {
			fmt.Println(":: [superinstall] Safely aborted deployment execution.")
			return
		}
	}

	fmt.Printf(":: [superinstall] Fetching remote source from Git Provider (GitLab): %s\n", gitURL)
	if err := RunCmdInDir(tmpDir, "git", "clone", "--depth=1", "--single-branch", gitURL); err != nil {
		os.Exit(1)
	}

	RunSharedBuildPipeline(filepath.Join(tmpDir, baseName), baseName, osName)
}