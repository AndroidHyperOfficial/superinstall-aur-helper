package backends

import (
	"fmt"
	"os/exec"
	"strings"
)

type DnfBackend struct{}

func (d *DnfBackend) GetOSName() string {
	return "fedora"
}

func (d *DnfBackend) Sync() {
	fmt.Println(":: [superinstall] Executing repository database synchronization mapping for: fedora")
	ExecuteSystemCommand("fedora", "dnf", []string{"makecache"}, true)
}

func (d *DnfBackend) Upgrade() {
	fmt.Println(":: [superinstall] Initiating global system transaction rollback and upgrades for: fedora")
	ExecuteSystemCommand("fedora", "dnf", []string{"upgrade", "-y"}, true)
}

func (d *DnfBackend) Search(query string) {
	fmt.Printf(":: [superinstall] Querying operational indexes for search trace: '%s'\n", query)
	ExecuteSystemCommand("fedora", "dnf", []string{"search", query}, false)
}

func (d *DnfBackend) Validate(pkgName string) bool {
	if strings.HasPrefix(pkgName, "http://") || strings.HasPrefix(pkgName, "https://") || strings.HasSuffix(pkgName, ".git") {
		return true
	}
	cmd := exec.Command("dnf", "list", "available", pkgName)
	return cmd.Run() == nil
}

func (d *DnfBackend) Install(pkgName string) {
	args := []string{"dnf", "install", "-y", pkgName}
	ExecuteSystemCommand("fedora", "sudo", args, false)
}