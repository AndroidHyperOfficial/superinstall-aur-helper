package backends

import (
	"fmt"
	"os/exec"
	"strings"
)

type GentooEmergeBackend struct{}

func (g *GentooEmergeBackend) GetOSName() string {
	return "gentoo"
}

func (g *GentooEmergeBackend) Sync() {
	fmt.Println(":: [superinstall] Executing repository database synchronization mapping for: gentoo")
	ExecuteSystemCommand("gentoo", "emaint", []string{"-a", "sync"}, true)
}

func (g *GentooEmergeBackend) Upgrade() {
	fmt.Println(":: [superinstall] Initiating global system transaction rollback and upgrades for: gentoo")
	ExecuteSystemCommand("gentoo", "emerge", []string{"-auDN", "@world"}, true)
}

func (g *GentooEmergeBackend) Search(query string) {
	fmt.Printf(":: [superinstall] Querying operational indexes for search trace: '%s'\n", query)
	ExecuteSystemCommand("gentoo", "emerge", []string{"--search", query}, false)
}

func (g *GentooEmergeBackend) Validate(pkgName string) bool {
	if strings.HasPrefix(pkgName, "http://") || strings.HasPrefix(pkgName, "https://") || strings.HasSuffix(pkgName, ".git") {
		return true
	}
	cmd := exec.Command("emerge", "--search", pkgName)
	return cmd.Run() == nil
}

func (g *GentooEmergeBackend) Install(pkgName string) {
	args := []string{"emerge", "--ask=n", pkgName}
	ExecuteSystemCommand("gentoo", "sudo", args, false)
}