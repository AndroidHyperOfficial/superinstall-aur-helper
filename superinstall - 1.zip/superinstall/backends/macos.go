package backends

import (
	"fmt"
	"os/exec"
	"strings"
)

type MacosBackend struct{}

func (m *MacosBackend) GetOSName() string {
	return "macos"
}

func (m *MacosBackend) Sync() {
	fmt.Println(":: [superinstall] Executing repository database synchronization mapping for: macos")
	ExecuteSystemCommand("macos", "brew", []string{"update"}, false)
}

func (m *MacosBackend) Upgrade() {
	fmt.Println(":: [superinstall] Initiating global system transaction rollback and upgrades for: macos")
	ExecuteSystemCommand("macos", "brew", []string{"upgrade"}, false)
}

func (m *MacosBackend) Search(query string) {
	fmt.Printf(":: [superinstall] Querying operational indexes for search trace: '%s'\n", query)
	ExecuteSystemCommand("macos", "brew", []string{"search", query}, false)
}

func (m *MacosBackend) Validate(pkgName string) bool {
	if strings.HasPrefix(pkgName, "http://") || strings.HasPrefix(pkgName, "https://") || strings.HasSuffix(pkgName, ".git") {
		return true
	}
	checkMac := exec.Command("brew", "info", pkgName)
	return checkMac.Run() == nil
}

func (m *MacosBackend) Install(pkgName string) {
	ExecuteSystemCommand("macos", "brew", []string{"install", pkgName}, false)
}