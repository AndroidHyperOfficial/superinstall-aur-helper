package backends

import (
	"fmt"
	"os/exec"
	"strings"
)

type BsdBackend struct {
	OS string
}

func (b *BsdBackend) GetOSName() string {
	return b.OS
}

func (b *BsdBackend) Sync() {
	fmt.Printf(":: [superinstall] Executing repository database synchronization mapping for: %s\n", b.OS)
	if b.OS == "freebsd" || b.OS == "netbsd" {
		ExecuteSystemCommand(b.OS, "pkg", []string{"update"}, true)
	}
}

func (b *BsdBackend) Upgrade() {
	fmt.Printf(":: [superinstall] Initiating global system transaction rollback and upgrades for: %s\n", b.OS)
	if b.OS == "freebsd" {
		ExecuteSystemCommand(b.OS, "pkg", []string{"upgrade", "-y"}, true)
	} else if b.OS == "openbsd" {
		ExecuteSystemCommand(b.OS, "syspatch", []string{}, true)
	} else if b.OS == "netbsd" {
		ExecuteSystemCommand(b.OS, "pkgin", []string{"upgrade", "-y"}, true)
	}
}

func (b *BsdBackend) Search(query string) {
	fmt.Printf(":: [superinstall] Querying operational indexes for search trace: '%s'\n", query)
	if b.OS == "openbsd" {
		ExecuteSystemCommand(b.OS, "pkg_info", []string{"-Q", query}, false)
	} else if b.OS == "netbsd" {
		ExecuteSystemCommand(b.OS, "pkgin", []string{"search", query}, false)
	} else {
		ExecuteSystemCommand(b.OS, "pkg", []string{"search", query}, false)
	}
}

func (b *BsdBackend) Validate(pkgName string) bool {
	if strings.HasPrefix(pkgName, "http://") || strings.HasPrefix(pkgName, "https://") || strings.HasSuffix(pkgName, ".git") {
		return true
	}
	var cmd *exec.Cmd
	if b.OS == "openbsd" {
		cmd = exec.Command("pkg_info", "-Q", pkgName)
	} else if b.OS == "netbsd" {
		cmd = exec.Command("pkgin", "search", pkgName)
	} else {
		cmd = exec.Command("pkg", "search", pkgName)
	}
	return cmd.Run() == nil
}

func (b *BsdBackend) Install(pkgName string) {
	var args []string
	if b.OS == "openbsd" {
		args = []string{"pkg_add", pkgName}
	} else if b.OS == "netbsd" {
		args = []string{"pkgin", "install", "-y", pkgName}
	} else {
		args = []string{"pkg", "install", "-y", pkgName}
	}
	ExecuteSystemCommand(b.OS, "sudo", args, false)
}