package backends

import (
	"fmt"
	"os/exec"
	"strings"
)

type ZypperBackend struct{}

func (z *ZypperBackend) GetOSName() string {
	return "opensuse"
}

func (z *ZypperBackend) Sync() {
	fmt.Println(":: [superinstall] Executing repository database synchronization mapping for: opensuse")
	ExecuteSystemCommand("opensuse", "zypper", []string{"refresh"}, true)
}

func (z *ZypperBackend) Upgrade() {
	fmt.Println(":: [superinstall] Initiating global system transaction rollback and upgrades for: opensuse")
	ExecuteSystemCommand("opensuse", "zypper", []string{"dup", "-y"}, true)
}

func (z *ZypperBackend) Search(query string) {
	fmt.Printf(":: [superinstall] Querying operational indexes for search trace: '%s'\n", query)
	ExecuteSystemCommand("opensuse", "zypper", []string{"search", query}, false)
}

func (z *ZypperBackend) Validate(pkgName string) bool {
	if strings.HasPrefix(pkgName, "http://") || strings.HasPrefix(pkgName, "https://") || strings.HasSuffix(pkgName, ".git") {
		return true
	}
	cmd := exec.Command("zypper", "search", "--match-exact", pkgName)
	return cmd.Run() == nil
}

func (z *ZypperBackend) Install(pkgName string) {
	args := []string{"zypper", "install", "-y", pkgName}
	ExecuteSystemCommand("opensuse", "sudo", args, false)
}