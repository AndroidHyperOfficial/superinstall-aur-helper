package backends

import (
	"fmt"
	"os/exec"
	"strings"
)

type AptBackend struct{}

func (a *AptBackend) GetOSName() string {
	return "debian"
}

func (a *AptBackend) Sync() {
	fmt.Println(":: [superinstall] Executing repository database synchronization mapping for: debian")
	ExecuteSystemCommand("debian", "apt-get", []string{"update"}, true)
}

func (a *AptBackend) Upgrade() {
	fmt.Println(":: [superinstall] Initiating global system transaction rollback and upgrades for: debian")
	ExecuteSystemCommand("debian", "apt-get", []string{"dist-upgrade", "-y"}, true)
}

func (a *AptBackend) Search(query string) {
	fmt.Printf(":: [superinstall] Querying operational indexes for search trace: '%s'\n", query)
	ExecuteSystemCommand("debian", "apt-cache", []string{"search", query}, false)
}

func (a *AptBackend) Validate(pkgName string) bool {
	if strings.HasPrefix(pkgName, "http://") || strings.HasPrefix(pkgName, "https://") || strings.HasSuffix(pkgName, ".git") {
		return true
	}
	cmd := exec.Command("apt-cache", "show", pkgName)
	return cmd.Run() == nil
}

func (a *AptBackend) Install(pkgName string) {
	args := []string{"apt-get", "install", "-y", pkgName}
	ExecuteSystemCommand("debian", "sudo", args, false)
}