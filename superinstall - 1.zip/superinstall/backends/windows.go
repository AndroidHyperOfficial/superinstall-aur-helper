package backends

import (
	"bytes"
	"fmt"
	"os/exec"
	"strings"
)

type WindowsBackend struct{}

func (w *WindowsBackend) GetOSName() string {
	return "windows"
}

func (w *WindowsBackend) Sync() {
	fmt.Println(":: [superinstall] Executing repository database synchronization mapping for: windows")
	ExecuteSystemCommand("windows", "winget", []string{"source", "update"}, false)
}

func (w *WindowsBackend) Upgrade() {
	fmt.Println(":: [superinstall] Initiating global system transaction rollback and upgrades for: windows")
	ExecuteSystemCommand("windows", "winget", []string{"upgrade", "--all"}, false)
}

func (w *WindowsBackend) Search(query string) {
	fmt.Printf(":: [superinstall] Querying operational indexes for search trace: '%s'\n", query)
	ExecuteSystemCommand("windows", "winget", []string{"search", query}, false)
}

func (w *WindowsBackend) Validate(pkgName string) bool {
	if strings.HasPrefix(pkgName, "http://") || strings.HasPrefix(pkgName, "https://") || strings.HasSuffix(pkgName, ".git") {
		return true
	}
	var out bytes.Buffer
	checkWin := exec.Command("winget", "search", "--exact", pkgName)
	checkWin.Stdout = &out
	_ = checkWin.Run()
	return !strings.Contains(out.String(), "No package found") && out.Len() > 0
}

func (w *WindowsBackend) Install(pkgName string) {
	ExecuteSystemCommand("windows", "winget", []string{"install", "--silent", pkgName}, false)
}